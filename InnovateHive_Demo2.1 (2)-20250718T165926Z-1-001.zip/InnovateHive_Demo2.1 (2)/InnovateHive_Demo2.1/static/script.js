<script>
  document.addEventListener('DOMContentLoaded', function () {
    // Sparkle animation
    function createSparkles() {
      const sparkle = document.createElement('div');
      sparkle.classList.add('sparkle');

      // Random position
      sparkle.style.left = Math.random() * window.innerWidth + 'px';
      sparkle.style.top = Math.random() * window.innerHeight + 'px';

      // Random size
      const size = Math.random() * 10 + 5;
      sparkle.style.width = size + 'px';
      sparkle.style.height = size + 'px';

      // Random animation duration
      sparkle.style.animationDuration = (Math.random() * 3 + 2) + 's';

      document.body.appendChild(sparkle);

      // Remove after animation completes
      setTimeout(() => {
        sparkle.remove();
      }, 2000);
    }

    // Create initial sparkles
    for (let i = 0; i < 50; i++) {
      setTimeout(createSparkles, Math.random() * 3000);
    }

    // Keep creating new sparkles
    setInterval(createSparkles, 300);

    // Scroll-in animation using IntersectionObserver
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target); // Animate only once
          }
        });
      },
      {
        threshold: 0.2
      }
    );

    // Observe all feature-box elements
    document.querySelectorAll('.feature-box').forEach((box) => {
      observer.observe(box);
    });
  });
</script>
