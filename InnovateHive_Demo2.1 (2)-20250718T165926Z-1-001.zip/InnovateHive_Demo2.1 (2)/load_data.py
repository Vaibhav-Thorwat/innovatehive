from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_core.documents import Document
import os

def create_vectorstore():
    with open("data/innovatehive.txt", "r", encoding="utf-8") as f:
        raw_text = f.read()

    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=500,
        chunk_overlap=100,
        separators=["\n\n", "\n", " ", ""]
    )
    docs = text_splitter.split_text(raw_text)
    documents = [Document(page_content=t) for t in docs]

    embeddings = HuggingFaceEmbeddings(
        model_name="sentence-transformers/all-MiniLM-L6-v2",
        model_kwargs={'device': 'cpu'}
    )

    vectorstore = FAISS.from_documents(documents, embeddings)

    if not os.path.exists("vector_store"):
        os.makedirs("vector_store")
    vectorstore.save_local("vector_store")
    print("✅ Vector store created successfully.")

if __name__ == "__main__":
    create_vectorstore()
    